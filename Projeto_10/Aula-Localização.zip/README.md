# 1DLocalization

Comandos interface:

r - reset
m - solicitar movimentação do robô
i - zoom in
o - zoom out

'space bar' - faz uma leitura e atualiza a predição
'up arrow' - movimenta o robô para frente de um tanto fixo, no caso 10 cm
'down arrow' - movimenta o robô para trás de um tanto fixo, no caso 10 cm
